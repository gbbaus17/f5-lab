#!/bin/bash

## This commande deletes all IPs from the Grey- and Shun-list

ipidr -c /Common/Hackazon_BaDOS_protected+/Common/Hackazon_BaDOS
ipidr -l /Common/Hackazon_BaDOS_protected+/Common/Hackazon_BaDOS



