#!/bin/bash
echo "Resetting L7-DOS Statistics...."

bigstart restart dosl7d
sleep 2

echo "Done."
