#!/bin/bash

# This script shows the learning status for the specific VS + Profile
# The first number is the % value

admd -s vs./Common/Hackazon_BaDOS_protected+/Common/Hackazon_BaDOS.info.learning
