#!/bin/bash

# This script lists the Grey-listed IPs

ipidr -l /Common/Hackazon_BaDOS_protected+/Common/Hackazon_BaDOS

